//
//  ViewController.swift
//  Great Number Game_laila_2
//
//  Created by administrator on 03/12/2021.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var GuessInput: UITextField!
    
    var RandomNumber = Int.random(in: 1...100)
    
    @IBAction func SubmitButton(_ sender: UIButton) {
        
        if GuessInput.text?.isEmpty == false{
            if Int(GuessInput.text!) == RandomNumber{
                let Dialog = UIAlertController(title: "Correct Guess", message: "You Guess \(GuessInput.text!) was correct!!\n want play again?", preferredStyle: .alert)
                
                let NO = UIAlertAction(title: "No", style: .default)
                
                let YES = UIAlertAction(title: "Yes", style: .cancel) {(_) -> Void in self.RandomNumber = Int.random(in: 0...100)}
                
                Dialog.addAction(YES)
                Dialog.addAction(NO)
                
                self.present(Dialog, animated: true, completion: nil)
                Dialog.view.backgroundColor = UIColor.green
                GuessInput.text = ""
                
            }else if Int(GuessInput.text!)! < RandomNumber{
                let Dialog = UIAlertController(title: "Incorrect Guess", message: "You Guess \(GuessInput.text!) is too low, you can try again", preferredStyle: .alert)
                
                let TryAgain = UIAlertAction(title: "Try again", style: .default)
                
                Dialog.addAction(TryAgain)
                
                self.present(Dialog, animated: true, completion: nil)
                Dialog.view.backgroundColor = UIColor.blue
                GuessInput.text = ""
                
            } else{
                let Dialog = UIAlertController(title: "Incorrect Guess", message: " You Guess \(GuessInput.text!) is too high, you can try again", preferredStyle: .alert)
                
                let TryAgain = UIAlertAction(title: "Try again", style: .default)
                
                Dialog.addAction(TryAgain)
                
                self.present(Dialog, animated: true, completion: nil)
                Dialog.view.backgroundColor = UIColor.red
                GuessInput.text = ""
                
            }
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

